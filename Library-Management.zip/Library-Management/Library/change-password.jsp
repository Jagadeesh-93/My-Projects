
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>

<%@ include file="header.jsp" %>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        /* Add your styling here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h1 {
            text-align: center;
            color: #1e73be;
        }
        label {
            display: block;
            margin-top: 10px;
            color: #333;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .submit-btn {
            padding: 10px 20px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .submit-btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Change Password</h1>
        
        <form method="post" action="">
            <div class="form-group">
                <label for="student-id">Student ID (Roll No):</label>
                <input type="text" id="student-id" name="roll_no" required>
            </div>

            <div class="form-group">
                <label for="old-password">Old Password:</label>
                <input type="password" id="old-password" name="old_password" required>
            </div>

            <div class="form-group">
                <label for="new-password">New Password:</label>
                <input type="password" id="new-password" name="new_password" required>
            </div>

            <button type="submit" class="submit-btn">Change Password</button>
        </form>
    </div>

<%
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/library";
    String user = "sairam";
    String password = "charan";
    
    // Check if the form has been submitted
    if (request.getMethod().equalsIgnoreCase("POST")) {
        // Get form data
        String rollNo = request.getParameter("roll_no");
        String oldPassword = request.getParameter("old_password");
        String newPassword = request.getParameter("new_password");
        if(newPassword.length()>5){

        // SQL query to check if roll number exists and get the old password
        String checkSql = "SELECT password FROM students WHERE roll = ?";
        String updateSql = "UPDATE students SET password = ? WHERE roll = ?";

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            Connection conn = DriverManager.getConnection(url, user, password);

            // Check if the roll number exists
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, rollNo);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                String dbOldPassword = rs.getString("password");

                // Check if the old password matches the one in the database
                if (dbOldPassword.equals(oldPassword)) {
                    // If old password matches, update the password
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setString(1, newPassword);  // Set the new password
                    updateStmt.setString(2, rollNo);  // Set the roll number
                    
                    int rowsAffected = updateStmt.executeUpdate();
                    if (rowsAffected > 0) {
                        out.println("<script>alert('Password changed successfully!');</script>");
                    } else {
                        out.println("<script>alert('Error changing password. Please try again.');</script>");
                    }
                    updateStmt.close();
                } else {
                    out.println("<script>alert('Old password is incorrect. Please try again.');</script>");
                }
            } else {
                out.println("<script>alert('Roll number not found. Please try again.');</script>");
            }

            // Close resources
            rs.close();
            checkStmt.close();
            conn.close();
        } catch (Exception e) {
            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
        }
    }
    else out.println("<script>alert('Password must contains 6 Characters');</script>");
    
    }
%>

</body>
</html>
