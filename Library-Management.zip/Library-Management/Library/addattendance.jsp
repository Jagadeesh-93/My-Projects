<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>

<%@ page import="java.sql.*, java.io.*"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Attendance</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; }
        h1 { text-align: center; color: #333; margin-top: 50px; }
        form { width: 40%; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); border-radius: 8px; margin-bottom: 30px; }
        label { font-size: 16px; color: #333; margin-bottom: 8px; display: block; }
        input[type="text"] { width: 100%; padding: 10px; margin: 8px 0; border-radius: 5px; border: 1px solid #ccc; box-sizing: border-box; }
        .message { text-align: center; margin-top: 10px; font-size: 16px; }
        .success { color: green; }
        .warning { color: orange; }
        .error { color: red; }
        input[type="text"]:focus {
            border: 2px solid #4CAF50;
        }
    </style>
    <script>
        // Auto-submit form on input (after 10 characters)
        function autoSubmit() {
            const inputField = document.getElementById("roll");
            inputField.addEventListener("input", function () {
                if (inputField.value.length === 10) { // Assuming roll number has 10 characters
                    document.getElementById("attendanceForm").submit(); // Submit the form
                }
            });
        }

        // Focus on the input field after submission
        function setFocus() {
            document.getElementById("roll").focus();
        }

        // Clear the input field after form submission
        function clearInputField() {
            document.getElementById("roll").value = "";
        }

        // Run autoSubmit and set focus on page load
        window.onload = function () {
            autoSubmit();
            setFocus();
        };
    </script>
</head>

<body onload="setFocus()">
    
    <h1>Add Attendance</h1>

    <!-- Form to input Roll Number -->
    <form id="attendanceForm" action="addattendance.jsp" method="post">
        <label for="roll">Scan Roll Number: </label>
        <input type="text" id="roll" name="roll" required maxlength="10" placeholder="Scan Roll Number" autofocus><br/>
        <div id="message" class="message"></div>
    </form>

    <%
        String roll = request.getParameter("roll");
        String message = "";
        String messageClass = "";

        if (roll != null && !roll.isEmpty()) {
            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                // Establish connection
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

                // Check if student exists in the database
                String studentQuery = "SELECT * FROM students WHERE roll = ?";
                stmt = conn.prepareStatement(studentQuery);
                stmt.setString(1, roll);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    // Check if attendance is already marked today
                    String checkQuery = "SELECT * FROM attendance WHERE roll = ? AND DATE(date_time) = CURDATE()";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                    checkStmt.setString(1, roll);
                    ResultSet checkRs = checkStmt.executeQuery();

                    if (checkRs.next()) {
                        // Attendance already marked
                        message = "Attendance already marked for Roll Number: " + roll;
                        messageClass = "warning";
                    } else {
                        // Mark attendance
                        String insertQuery = "INSERT INTO attendance (roll, date_time) VALUES (?, NOW())";
                        PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                        insertStmt.setString(1, roll);
                        int rowsAffected = insertStmt.executeUpdate();

                        if (rowsAffected > 0) {
                            message = "Attendance marked successfully for Roll Number: " + roll;
                            messageClass = "success";
                        } else {
                            message = "Failed to mark attendance. Try again later.";
                            messageClass = "error";
                        }
                        insertStmt.close();
                    }
                    checkRs.close();
                    checkStmt.close();
                } else {
                    // Invalid roll number
                    out.println("<script>alert('Invalid Roll Number!');</script>");
                }
            } catch (Exception e) {
                e.printStackTrace();
                out.println("<script>alert('An error occurred while processing attendance.');</script>");
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    %>

    <script>
        // Display the message dynamically under the input field
        document.getElementById("message").innerHTML = "<span class='<%= messageClass %>'><%= message %></span>";
        // Clear the text field for next input
        clearInputField();
        // Highlight the text field again
        setFocus();
    </script>
</body>
</html>
