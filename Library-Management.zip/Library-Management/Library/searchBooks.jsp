<%@ page import="java.sql.*" %>

<%
    String query = request.getParameter("query");
    if (query != null && query.length() > 2) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Load MySQL driver and establish a connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

            // SQL query to get book names that match the input query
            String sql = "SELECT title FROM books WHERE title LIKE ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + query + "%");

            // Execute query and fetch results
            rs = pstmt.executeQuery();

            // Iterate over the results and print each suggestion
            while (rs.next()) {
                String title = rs.getString("title");
                out.println("<div onclick='selectSuggestion(\"" + title + "\")'>" + title + "</div>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
            if (pstmt != null) try { pstmt.close(); } catch (SQLException ignore) {}
            if (con != null) try { con.close(); } catch (SQLException ignore) {}
        }
    }
%>
