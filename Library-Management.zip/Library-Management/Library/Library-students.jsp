
<%@ page import="java.sql.*" %>
<%@ include file="header1.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <title>Library Data - All Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 10px;
            padding: 0;
        }

        h1 {
            color: #1e73be;
            text-align: center;
            margin-bottom: 20px;
        }

        .filter-form {
            text-align: center;
            margin-bottom: 20px;
            position: relative; /* Added position relative for positioning suggestions */
        }

        .filter-form label {
            font-weight: bold;
        }

        .filter-form select, .filter-form input[type="text"] {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            margin-right: 10px;
            display: inline-block; /* Ensure they line up horizontally */
        }

        .filter-form input[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
            text-align: center;
        }

        th, td {
            padding: 10px;
            font-size: 14px;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .suggestions {
            border: 1px solid #ccc;
            max-height: 100px;
            overflow-y: auto;
            position:absolute; /* Position absolute to overlay suggestions */
            width: 16%; /* Adjust width to match the input */
            background-color: white;
            z-index: 1000; /* Ensure it appears above other elements */
            display: none; /* Initially hide suggestions */
            left: 57%;
        }

        .suggestions div {
            padding: 8px;
            cursor: pointer;
        }

        .suggestions div:hover {
            background-color: #f1f1f1;
        }
    </style>

    <script>
        // Function to get suggestions from the server
        function getSuggestions() {
            var input = document.getElementById("search").value;
            if (input.length > 2) {  // Only suggest when input length > 2
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "searchBooks.jsp?query=" + input, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        var suggestionsDiv = document.getElementById("suggestions");
                        suggestionsDiv.innerHTML = xhr.responseText;
                        suggestionsDiv.style.display = "block"; // Show suggestions
                    }
                };
                xhr.send();
            } else {
                document.getElementById("suggestions").innerHTML = "";
                document.getElementById("suggestions").style.display = "none"; // Hide suggestions
            }
        }

        // Function to select a suggestion
        function selectSuggestion(value) {
            document.getElementById("search").value = value;
            document.getElementById("suggestions").innerHTML = "";
            document.getElementById("suggestions").style.display = "none"; // Hide suggestions after selection
        }
    </script>
</head>
<body>
    <h1>Library Book Collection</h1>
    <div class="filter-form">
        <form action="Library-students.jsp" method="post">
            <label for="type">Select Book Type:</label>
            <select name="type" id="type">
                <option value="all">All</option>
                <option value="curriculum">Curriculum</option>
                <option value="novel">Novel</option>
                <option value="hstudy">Higher Studies</option>
                <option value="magazine">Magazine</option>
            </select>
            <label for="search">Search by Book Name:</label>
            <input type="text" name="search" id="search" onkeyup="getSuggestions()" autocomplete="off">
            <div id="suggestions" class="suggestions"></div> 
            <input type="submit" value="Filter">
        </form>
    </div>
    <table border="5">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Semester</th>
            <th>Type</th>
            <th>Remaining</th>
            <th>Total</th>

        </tr>
        <%
            // Get the selected book type and search query from the form
            String selectedType = request.getParameter("type");
            String searchQuery = request.getParameter("search");

            if (selectedType == null) {
                selectedType = "all";  // Default to "all" if no type is selected
            }

            // JDBC connection to retrieve books data from the database
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            try {
                // Load the MySQL driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the connection to the database
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

                // SQL query based on selected type and search query
                String query = "SELECT * FROM books WHERE 1=1";  // Always true

                if (!selectedType.equals("all")) {
                    query += " AND type = ?";
                }

                if (searchQuery != null && !searchQuery.isEmpty()) {
                    query += " AND title LIKE ?";
                }

                pstmt = con.prepareStatement(query);

                int paramIndex = 1;
                if (!selectedType.equals("all")) {
                    pstmt.setString(paramIndex++, selectedType);  // Set the parameter for book type
                }

                if (searchQuery != null && !searchQuery.isEmpty()) {
                    pstmt.setString(paramIndex++, "%" + searchQuery + "%");  // Set the parameter for book name
                }

                // Execute the query
                rs = pstmt.executeQuery();

                // Iterate over the result set and display each book's data
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String title = rs.getString("title");
                    String author = rs.getString("author");
                    int sem = rs.getInt("sem");
                    String type = rs.getString("type");
                    int total=rs.getInt("total");
                    int quantity = rs.getInt("quantity");
                    // Output the data into the table
                    %>
                    <tr>
                        <td><%= id %></td>
                        <td><%= title %></td>
                        <td><%= author %></td>
                        <td><%= sem %></td>
                        <td><%= type %></td>
                        <td><%= quantity %></td>
                        <td><%= total %></td>
                    </tr>
                    <%
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                // Close resources
                if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
                if (pstmt != null) try { pstmt.close(); } catch (SQLException ignore) {}
                if (con != null) try { con.close(); } catch (SQLException ignore) {}
            }
        %>
    </table>
</body>
</html>
