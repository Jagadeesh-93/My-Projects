<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.temporal.ChronoUnit" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .search-bar {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }

        input[type="text"] {
            padding: 10px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f0f0f0;
        }

        .btn {
            padding: 8px 12px;
            color: white;
            background-color: #218838;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn.renew {
            background-color: #007bff;
        }

        .btn.return {
            background-color: #dc3545;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .no-records {
            text-align: center;
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
.back-btn {
    padding: 8px 12px; /* Same padding as .btn for consistency */
    color: white;
    background-color: #218838; /* Same green color */
    border: none;
    border-radius: 5px; /* Rounded corners */
    cursor: pointer;
    font-size: 16px; /* Same font size as .btn */
    transition: opacity 0.3s ease; /* Smooth hover effect */
}

.back-btn:hover {
    opacity: 0.9; /* Same hover effect as .btn */
}



    </style>
</head>
<body>

    <div class="container">
        <h1>Student Data</h1>

        <div class="search-bar">
            <form method="POST" action="sbdata.jsp">
                <input type="text" name="rollno" placeholder="Enter Roll No" required>
                <button class="btn" type="submit">Search</button>
                
                
            </form>
        </div>

        <table id="studentTable">
            <thead>
                <tr>
                    <th>Student Roll No</th>
                    <th>Name</th>
                    <th>Book ID</th>
                    <th>Book Name</th>
                    <th>Issued Date</th>
                    <th>End Date</th>
                    <th>Fine</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <%
                    // Update all fines when "Update All Fines" is clicked
                        try {
                            String updateFineSql = "UPDATE s_book SET fine = GREATEST(DATEDIFF(CURDATE(), submit_date), 0) WHERE submit_date IS NOT NULL";
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");
                            PreparedStatement pstmt = con.prepareStatement(updateFineSql);
                            pstmt.executeUpdate();
                            pstmt.close();
                            con.close();
                           
                        } catch (Exception e) {
                            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
                        }
                    

                    String rollno = request.getParameter("rollno");

                    if (rollno != null) {
                        Connection con = null;
                        PreparedStatement pstmt = null;
                        ResultSet rs = null;

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

                            String query = "SELECT students.roll, students.name, books.id AS bookId, books.title AS bookName, " +
                                            "s_book.borrow_date AS issuedDate, s_book.submit_date AS endDate, s_book.fine " +
                                            "FROM students " +
                                            "JOIN s_book ON students.roll = s_book.roll_no " +
                                            "JOIN books ON s_book.id = books.id " +
                                            "WHERE students.roll = ?";

                            pstmt = con.prepareStatement(query);
                            pstmt.setString(1, rollno);
                            rs = pstmt.executeQuery();

                            if (!rs.isBeforeFirst()) {
                %>
                                <tr>
                                    <td colspan="8" class="no-records">No records found for Roll No: <%= rollno %></td>
                                </tr>
                <%
                            } else {
                                while (rs.next()) {
                                    int fine = rs.getInt("fine"); // Get the fine from the result set
                %>
                                <tr>
                                    <td><%= rs.getString("roll") %></td>
                                    <td><%= rs.getString("name") %></td>
                                    <td><%= rs.getInt("bookId") %></td>
                                    <td><%= rs.getString("bookName") %></td>
                                    <td><%= rs.getDate("issuedDate") %></td>
                                    <td><%= rs.getDate("endDate") %></td>
                                    <td><%= fine %></td>
                                    
                                    <td>
                                        <form method="post" action="">
                                            <input type="hidden" name="book_id" value="<%= rs.getInt("bookId") %>">
                                            <input type="hidden" name="roll_no" value="<%= rs.getString("roll") %>">
                                            <button class="btn renew" type="submit" name="renew">Renew</button>
                                        </form>
                                        <form method="post" action="">
                                            <input type="hidden" name="book_id" value="<%= rs.getInt("bookId") %>">
                                            <input type="hidden" name="roll_no" value="<%= rs.getString("roll") %>">
                                            <button class="btn return" type="submit" name="return">Return</button>
                                        </form>
                                    </td>
                                </tr>
<%
                                }
                            }
                        } catch (Exception e) {
                            out.println("Error: " + e.getMessage());
                        } finally {
                            if (rs != null) rs.close();
                            if (pstmt != null) pstmt.close();
                            if (con != null) con.close();
                        }
                    }

                    // Renew functionality
                    if (request.getParameter("renew") != null) {
                        String bookId = request.getParameter("book_id");
                        String rollNo = request.getParameter("roll_no");
                    
                        // Fetch the fine and renewal count
                        Connection con = null;
                        PreparedStatement pstmt = null;
                        ResultSet rs = null;
                    
                        try {
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");
                    
                            // Fetch the fine and renewal_count from s_book
                            String selectSql = "SELECT fine, renewal_count FROM s_book WHERE roll_no = ? AND id = ?";
                            pstmt = con.prepareStatement(selectSql);
                            pstmt.setString(1, rollNo);
                            pstmt.setInt(2, Integer.parseInt(bookId));
                            rs = pstmt.executeQuery();
                    
                            int fine = 0;
                            int renewalCount = 0;
                            if (rs.next()) {
                                fine = rs.getInt("fine"); // Get fine value from s_book
                                renewalCount = rs.getInt("renewal_count"); // Get renewal_count from s_book
                            }
                    
                            // If the renewal_count is 1, show alert and do not proceed
                            if (renewalCount == 1) {
                                out.println("<script>alert('You must return the book before renewing again.');</script>");
                                return;
                            }
                    
                            LocalDate currentDate = LocalDate.now();
                            LocalDate newSubmitDate = currentDate.plus(1, ChronoUnit.MONTHS);
                    
                            // If fine > 0, insert payment into fine_payments table
                            if (fine > 0) {
                                String insertPaymentSql = "INSERT INTO fine_payments (roll_no, book_id, fine_amount, payment_date) VALUES (?, ?, ?, ?)";
                                PreparedStatement paymentPstmt = con.prepareStatement(insertPaymentSql);
                                paymentPstmt.setString(1, rollNo);
                                paymentPstmt.setInt(2, Integer.parseInt(bookId));
                                paymentPstmt.setInt(3, fine);
                                paymentPstmt.setDate(4, Date.valueOf(currentDate));
                                paymentPstmt.executeUpdate();
                                paymentPstmt.close();
                            }
                    
                            // Update the s_book table for the renewal, reset fine to 0, and update renewal_count to 1
                            String updateSql = "UPDATE s_book SET borrow_date = ?, submit_date = ?, fine = ?, renewal_count = ? WHERE roll_no = ? AND id = ?";
                            pstmt = con.prepareStatement(updateSql);
                            pstmt.setDate(1, Date.valueOf(currentDate));
                            pstmt.setDate(2, Date.valueOf(newSubmitDate));
                            pstmt.setInt(3, 0);  // Reset fine to 0
                            pstmt.setInt(4, 1);  // Set renewal_count to 1
                            pstmt.setString(5, rollNo);
                            pstmt.setInt(6, Integer.parseInt(bookId));
                            pstmt.executeUpdate();
                    
                            // Insert into borrowing_history for renewal
                            String insertHistorySql = "INSERT INTO borrowing_history (roll_no, book_id, event_type, transaction_date) VALUES (?, ?, ?, ?)";
                            PreparedStatement historyPstmt = con.prepareStatement(insertHistorySql);
                            historyPstmt.setString(1, rollNo);
                            historyPstmt.setInt(2, Integer.parseInt(bookId));
                            historyPstmt.setString(3, "renew");
                            historyPstmt.setDate(4, Date.valueOf(currentDate));
                            historyPstmt.executeUpdate();
                            historyPstmt.close();
                    
                            con.close();
                    
                            out.println("<script>alert('Book renewed successfully!');</script>");
                        } catch (Exception e) {
                            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
                        }
                    }
                    

                    // Return functionality
                    
                    if (request.getParameter("return") != null) {
                        String bookId = request.getParameter("book_id");
                        String rollNo = request.getParameter("roll_no");
                
                        // Fetch fine
                        Connection con = null;
                        PreparedStatement pstmt = null;
                        ResultSet rs = null;
                
                        try {
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");
                
                            String selectSql = "SELECT fine FROM s_book WHERE roll_no = ? AND id = ?";
                            pstmt = con.prepareStatement(selectSql);
                            pstmt.setString(1, rollNo);
                            pstmt.setInt(2, Integer.parseInt(bookId));
                            rs = pstmt.executeQuery();
                
                            int fine = 0;
                            if (rs.next()) {
                                fine = rs.getInt("fine"); // Get fine value from s_book
                            }
                
                            LocalDate currentDate = LocalDate.now();
                
                            // If fine > 0, insert into fine_payments
                            if (fine > 0) {
                                String insertPaymentSql = "INSERT INTO fine_payments (roll_no, book_id, fine_amount, payment_date) VALUES (?, ?, ?, ?)";
                                PreparedStatement paymentPstmt = con.prepareStatement(insertPaymentSql);
                                paymentPstmt.setString(1, rollNo);
                                paymentPstmt.setInt(2, Integer.parseInt(bookId));
                                paymentPstmt.setInt(3, fine);
                                paymentPstmt.setDate(4, Date.valueOf(currentDate));
                                paymentPstmt.executeUpdate();
                                paymentPstmt.close();
                            }
                
                            // Delete from s_book
                            String deleteSql = "DELETE FROM s_book WHERE roll_no = ? AND id = ?";
                            PreparedStatement deletePstmt = con.prepareStatement(deleteSql);
                            deletePstmt.setString(1, rollNo);
                            deletePstmt.setInt(2, Integer.parseInt(bookId));
                            deletePstmt.executeUpdate();
                            deletePstmt.close();
                
                            // Insert into borrowing_history for return
                            String insertHistorySql = "INSERT INTO borrowing_history (roll_no, book_id, event_type, transaction_date) VALUES (?, ?, ?, ?)";
                            PreparedStatement historyPstmt = con.prepareStatement(insertHistorySql);
                            historyPstmt.setString(1, rollNo);
                            historyPstmt.setInt(2, Integer.parseInt(bookId));
                            historyPstmt.setString(3, "return");
                            historyPstmt.setDate(4, Date.valueOf(currentDate));
                            historyPstmt.executeUpdate();
                            historyPstmt.close();
                
                            // Increment book quantity in the books table
                            String updateBookQuantitySql = "UPDATE books SET quantity = quantity + 1 WHERE id = ?";
                            PreparedStatement updateQuantityPstmt = con.prepareStatement(updateBookQuantitySql);
                            updateQuantityPstmt.setInt(1, Integer.parseInt(bookId));
                            updateQuantityPstmt.executeUpdate();
                            updateQuantityPstmt.close();

                            // Decrease the count of borrowed books in the students table
                            String updateStudentCountSql = "UPDATE students SET count = count - 1 WHERE roll = ?";
                            PreparedStatement updateStudentCountPstmt = con.prepareStatement(updateStudentCountSql);
                            updateStudentCountPstmt.setString(1, rollNo);
                            int rowsUpdated = updateStudentCountPstmt.executeUpdate();

                            // Check if the count update was successful
                            if (rowsUpdated > 0) {
                                out.println("<script>alert('Book returned successfully!');</script>");
                            } else {
                                out.println("<script>alert('Error: Unable to update student record.');</script>");
                            }
                            updateStudentCountPstmt.close();

                        } catch (Exception e) {
                            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
                        }
                    }
                
                
                %>
            </tbody>
        </table>
    </div>

</body>
</html>