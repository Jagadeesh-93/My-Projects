<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowing History</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

h1 {
    text-align: center;
    color: #006400;
}

form {
    margin-bottom: 20px;
    text-align: center;
}

form label {
    font-size: 16px;
    color: #333;
}

form input {
    padding: 10px;
    font-size: 16px;
    width: 250px;
    margin-right: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

form button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #006400;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

form button:hover {
    background-color: #089e08;
}

table {
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
}

table th, table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

table th {
    background-color: #006400;
    color: white;
}

table tr:hover {
    background-color: #f1f1f1;
}

.back-btn {
    padding: 10px 20px;
    background-color: #28a745;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.back-btn:hover {
    opacity: 0.9;
}

    </style>
</head>
<body>

    <div class="container">
        <h1>Borrowing History</h1>

        <!-- Search Form -->
        <form method="post" action="">
            <label for="search-roll">Search by Student ID:</label>
            <input type="text" id="search-roll" name="search_roll" placeholder="Enter Roll Number">
            <button type="submit" class="submit-btn">Search</button>
        </form>

        <br>

        <!-- Borrowing History Table -->
        <table>
            <thead>
                <tr>
                    <th>History ID</th>
                    <th>Student ID</th>
                    <th>Book ID</th>
                    <th>Event Type</th>
                    <th>Transaction Date</th>
                </tr>
            </thead>
            <tbody>
                <%
                    // Database connection parameters
                    String url = "jdbc:mysql://localhost:3306/library"; // Change to your database name
                    String user = "sairam"; // Change to your database username
                    String password = "charan"; // Change to your database password

                    String searchRoll = request.getParameter("search_roll");

                    try {
                        // Load MySQL JDBC driver
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        // Establish the connection
                        Connection conn = DriverManager.getConnection(url, user, password);

                        // SQL query to fetch data from borrowing_history
                        String sql;
                        if (searchRoll != null && !searchRoll.isEmpty()) {
                            sql = "SELECT * FROM borrowing_history WHERE roll_no = ?";
                        } else {
                            sql = "SELECT * FROM borrowing_history"; // Show all data by default
                        }

                        // Create a prepared statement
                        PreparedStatement stmt = conn.prepareStatement(sql);
                        if (searchRoll != null && !searchRoll.isEmpty()) {
                            stmt.setString(1, searchRoll); // Set the roll number parameter
                        }

                        // Execute the query
                        ResultSet rs = stmt.executeQuery();

                        // Loop through the result set and display each row in the table
                        while (rs.next()) {
                            int historyId = rs.getInt("history_id");
                            String rollNo = rs.getString("roll_no");
                            int bookId = rs.getInt("book_id");
                            String eventType = rs.getString("event_type");
                            Date transactionDate = rs.getDate("transaction_date");
                %>
                            <tr>
                                <td><%= historyId %></td>
                                <td><%= rollNo %></td>
                                <td><%= bookId %></td>
                                <td><%= eventType %></td>
                                <td><%= transactionDate %></td>
                            </tr>
                <%
                        }

                        // Close the resources
                        rs.close();
                        stmt.close();
                        conn.close();

                    } catch (Exception e) {
                        out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
                    }
                %>
            </tbody>
        </table>

        <br>
        
    </div>

</body>
</html>
