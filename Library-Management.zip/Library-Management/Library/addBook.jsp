<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
        }
        h1 {
            color: #0056b3;
            font-size: 24px;
            margin-bottom: 30px;
        }
        label {
            display: block;
            font-size: 16px;
            margin: 10px 0 5px;
            text-align: left;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 150px;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
.back-btn {
    padding: 8px 12px; /* Same padding as .btn for consistency */
    color: white;
    background-color: #218838; /* Same green color */
    border: none;
    border-radius: 5px; /* Rounded corners */
    cursor: pointer;
    font-size: 16px; /* Same font size as .btn */
    transition: opacity 0.3s ease; /* Smooth hover effect */
}

.back-btn:hover {
    opacity: 0.9; /* Same hover effect as .btn */
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Book</h1>

        <!-- Form for Adding Book -->
        <form action="addBook.jsp" method="post">
            <label for="id">ID:</label>
            <input type="number" name="id" id="id" required>

            <label for="title">Title:</label>
            <input type="text" name="title" id="title" required>

            <label for="author">Author:</label>
            <input type="text" name="author" id="author" required>

            <label for="sem">Semester:</label>
            <input type="number" name="sem" id="sem" required>

            <label for="type">Type:</label>
            <select name="type" id="type" required>
                <option value="curriculum">Curriculum</option>
                <option value="novel">Novel</option>
                <option value="hstudy">Higher Studies</option>
                <option value="magazine">Magazine</option>
            </select>

            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" id="quantity" required>

            <input type="submit" value="Add Book">
	

        </form>

        <% 
        // Handle form submission and insert book into the database
        if (request.getMethod().equalsIgnoreCase("POST")) {
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String author = request.getParameter("author");
            int sem = Integer.parseInt(request.getParameter("sem"));
            String type = request.getParameter("type");
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            try {
                // Load MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish a connection to the MySQL database
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

                // First, check if the book already exists by its ID
                String checkQuery = "SELECT * FROM books WHERE id = ?";
                pstmt = con.prepareStatement(checkQuery);
                pstmt.setInt(1, id);
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    // If book with the same ID already exists
                    out.println("<script>alert('A book with this ID already exists. Please use a different ID.');</script>");
                } else {
                    // SQL query to insert the book into the database
                    String sql = "INSERT INTO books (id, title, author, sem, type, quantity,total) VALUES (?, ?, ?, ?, ?, ?,?)";
                    pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, id);
                    pstmt.setString(2, title);
                    pstmt.setString(3, author);
                    pstmt.setInt(4, sem);
                    pstmt.setString(5, type);
                    pstmt.setInt(6, quantity);
                    pstmt.setInt(7,quantity);

                    // Execute the query and check if a row was inserted
                    int rowsInserted = pstmt.executeUpdate();
                    if (rowsInserted > 0) {
                        out.println("<script>alert('Book added successfully!');</script>");
                    } else {
                        out.println("<script>alert('Failed to add the book.');</script>");
                    }
                }
            } catch (SQLException e) {
                // Show specific error message if there's an SQL exception
                out.println("<script>alert('Database error: " + e.getMessage() + "');</script>");
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                // Show error message if JDBC driver is not found
                out.println("<script>alert('JDBC Driver not found: " + e.getMessage() + "');</script>");
                e.printStackTrace();
            } catch (Exception e) {
                // Catch any other unforeseen exceptions
                out.println("<script>alert('Unexpected error: " + e.getMessage() + "');</script>");
                e.printStackTrace();
            } finally {
                if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
                if (pstmt != null) try { pstmt.close(); } catch (SQLException ignore) {}
                if (con != null) try { con.close(); } catch (SQLException ignore) {}
            }
        }
        %>
    </div>
</body>
</html>
