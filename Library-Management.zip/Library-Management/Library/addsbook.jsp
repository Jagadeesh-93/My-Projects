<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.temporal.ChronoUnit" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #1e73be;
        }

        label {
            display: block;
            margin-top: 10px;
            color: #333;
        }

        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .submit-btn {
            padding: 10px 20px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .submit-btn:hover {
            opacity: 0.9;
        }
	.back-btn {
            padding: 10px 20px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .back-btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Add Book</h1>
        
        <form method="post" action="">
            <div class="form-group">
                <label for="student-id">Student ID:</label>
                <input type="text" id="student-id" name="roll_no" required>
            </div>

            <div class="form-group">
                <label for="book-id">Book ID:</label>
                <input type="text" id="book-id" name="id" required>
            </div>

            <div class="form-group">
                <label for="issue-date">Issued Date:</label>
                <input type="date" id="issue-date" name="borrow_date" readonly>
            </div>

            <button type="submit" class="submit-btn">Submit</button>
            
        </form>
    </div>

    <script>
        window.onload = function() {
            const today = new Date();
            const formattedDate = today.toISOString().slice(0, 10); // Format as yyyy-mm-dd
            document.getElementById('issue-date').value = formattedDate;
        };
    </script>

<%
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/library"; // Change to your database name
    String user = "sairam"; // Change to your database username
    String password = "charan"; // Change to your database password

    // Check if the form has been submitted
    if (request.getMethod().equalsIgnoreCase("POST")) {
        // Get form data
        String rollNo = request.getParameter("roll_no");
        String bookId = request.getParameter("id");
        String borrowDate = request.getParameter("borrow_date");

        // Parse borrowDate to LocalDate for calculation
        LocalDate issueDate = LocalDate.parse(borrowDate);
        // Automatically calculate the submit date as 1 month after the issue date
        LocalDate submitDate = issueDate.plus(1, ChronoUnit.MONTHS);

        // SQL queries
        String checkDuplicateSql = "SELECT COUNT(*) FROM s_book WHERE roll_no = ? AND id = ?";
        String checkStudentCountSql = "SELECT count FROM students WHERE roll = ?";
        String checkBookQuantitySql = "SELECT quantity FROM books WHERE id = ?";
        String updateBookQuantitySql = "UPDATE books SET quantity = quantity - 1 WHERE id = ?";
        String sql = "INSERT INTO s_book (roll_no, id, borrow_date, submit_date) VALUES (?, ?, ?, ?)";
        String historySql = "INSERT INTO borrowing_history (roll_no, book_id, event_type, transaction_date) VALUES (?, ?, ?, ?)";

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            Connection conn = DriverManager.getConnection(url, user, password);

            // Check if the same student and book already exist
            PreparedStatement checkStmt = conn.prepareStatement(checkDuplicateSql);
            checkStmt.setString(1, rollNo);
            checkStmt.setInt(2, Integer.parseInt(bookId));
            ResultSet rs = checkStmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);

            // Check the student's count of borrowed books
            PreparedStatement studentStmt = conn.prepareStatement(checkStudentCountSql);
            studentStmt.setString(1, rollNo);
            ResultSet studentRs = studentStmt.executeQuery();
            studentRs.next();
            int studentCount = studentRs.getInt(1);

            // Check the quantity of the book
            PreparedStatement quantityStmt = conn.prepareStatement(checkBookQuantitySql);
            quantityStmt.setInt(1, Integer.parseInt(bookId));
            ResultSet quantityRs = quantityStmt.executeQuery();
            quantityRs.next();
            int quantity = quantityRs.getInt(1);

            // If student has borrowed 6 books, show an alert
            if (studentCount >= 6) {
                out.println("<script>alert('You can only borrow up to 6 books.');</script>");
            } else if (quantity == 0) {
                out.println("<script>alert('This book is currently unavailable.');</script>");
            } else if (count > 0) {
                // If duplicate found, show alert
                out.println("<script>alert('This book has already been issued to this student.');</script>");
            } else {
                // No duplicate found, proceed with insertion and updating quantity
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, rollNo);
                pstmt.setInt(2, Integer.parseInt(bookId));
                pstmt.setDate(3, Date.valueOf(borrowDate));
                pstmt.setDate(4, Date.valueOf(submitDate));

                // Execute the s_book insert statement and get the number of affected rows
                int rowsAffected = pstmt.executeUpdate();

                // Insert transaction into borrowing_history
                PreparedStatement historyPstmt = conn.prepareStatement(historySql);
                historyPstmt.setString(1, rollNo);
                historyPstmt.setInt(2, Integer.parseInt(bookId));
                historyPstmt.setString(3, "borrow"); // Event type is "borrow"
                historyPstmt.setDate(4, Date.valueOf(borrowDate));

                // Execute the history insert statement
                int historyRowsAffected = historyPstmt.executeUpdate();

                // Update the book quantity
                PreparedStatement updateStmt = conn.prepareStatement(updateBookQuantitySql);
                updateStmt.setInt(1, Integer.parseInt(bookId));
                int updateRowsAffected = updateStmt.executeUpdate();

                // Update student's book count
                String updateStudentCountSql = "UPDATE students SET count = count + 1 WHERE roll = ?";
                PreparedStatement updateCountStmt = conn.prepareStatement(updateStudentCountSql);
                updateCountStmt.setString(1, rollNo);
                int updateCountRowsAffected = updateCountStmt.executeUpdate();

                // Close resources
                pstmt.close();
                historyPstmt.close();
                checkStmt.close();
                studentStmt.close();
                quantityStmt.close();
                updateStmt.close();
                updateCountStmt.close();
                conn.close();

                // Show the appropriate alert
                if (rowsAffected > 0 && historyRowsAffected > 0 && updateRowsAffected > 0 && updateCountRowsAffected > 0) {
                    out.println("<script>alert('Book added, transaction recorded in history, and book quantity updated!');</script>");
                } else {
                    out.println("<script>alert('Error: No rows affected in s_book, borrowing_history, or books. Try again.');</script>");
                }
            }

            // Close result set
            rs.close();
            studentRs.close();
            quantityRs.close();

        } catch (Exception e) {
            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
        }
    }
%>
 
</body>
</html>
