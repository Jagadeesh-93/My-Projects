<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .search-bar {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        input[type="text"] {
            padding: 10px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            opacity: 0.9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .no-records {
            text-align: center;
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment History</h1>
        <div class="search-bar">
            <form method="GET" action="payments.jsp">
                <input type="text" name="rollno" placeholder="Enter Roll No">
                <button class="btn" type="submit">Search</button>
            </form>
            <!-- Button to show all data -->
            <form method="GET" action="payments.jsp">
                <button class="btn" type="submit" name="show_all" value="true">Show All Data</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>Payment Date</th>
                    <th>Roll No</th>
                    <th>Book ID</th>
                    <th>Fine Amount (Rs)</th>
                </tr>
            </thead>
            <tbody>
                <%
                    // Database connection details
                    String dbUrl = "jdbc:mysql://localhost:3306/library";
                    String dbUser = "sairam";
                    String dbPassword = "charan";

                    Connection con = null;
                    PreparedStatement pstmt = null;
                    ResultSet rs = null;

                    String rollno = request.getParameter("rollno");
                    boolean showAll = request.getParameter("show_all") != null;

                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

                        // SQL query to fetch payment history from the fine_payments table
                        String query = "SELECT id, payment_date, roll_no, book_id, fine_amount FROM fine_payments WHERE fine_amount >0";

                        if (!showAll && rollno != null && !rollno.isEmpty()) {
                            query += " AND roll_no = ?";
                            pstmt = con.prepareStatement(query);
                            pstmt.setString(1, rollno);
                        } else {
                            pstmt = con.prepareStatement(query);
                        }

                        rs = pstmt.executeQuery();

                        if (!rs.isBeforeFirst()) { // No records found
                %>
                            <tr>
                                <td colspan="5" class="no-records">No records found</td>
                            </tr>
                <%
                        } else {
                            while (rs.next()) {
                %>
                                <tr>
                                    <td><%= rs.getInt("id") %></td>
                                    <td><%= rs.getDate("payment_date") %></td>
                                    <td><%= rs.getString("roll_no") %></td>
                                    <td><%= rs.getInt("book_id") %></td>
                                    <td><%= rs.getInt("fine_amount") %></td>
                                </tr>
                <%
                            }
                        }
                    } catch (Exception e) {
                        out.println("<tr><td colspan='5' class='no-records'>Error: " + e.getMessage() + "</td></tr>");
                    } finally {
                        if (rs != null) try { rs.close(); } catch (Exception ignore) {}
                        if (pstmt != null) try { pstmt.close(); } catch (Exception ignore) {}
                        if (con != null) try { con.close(); } catch (Exception ignore) {}
                    }
                %>
            </tbody>
        </table>
    </div>
</body>
</html>
