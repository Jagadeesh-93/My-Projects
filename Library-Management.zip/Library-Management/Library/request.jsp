<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Request Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f0f0f0;
        }

        .btn {
            padding: 8px 12px;
            color: white;
            background-color: #218838;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn.return {
            background-color: #dc3545;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .no-records {
            text-align: center;
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Request Table</h1>
        <table>
            <thead>
                <tr>
                    <th>RID</th>
                    <th>Roll</th>
                    <th>Book Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <%
                    String url = "jdbc:mysql://localhost:3306/library";
                    String username = "sairam";
                    String password = "charan";

                    Connection conn = null;
                    PreparedStatement pstmt = null;
                    ResultSet rs = null;

                    try {
                        conn = DriverManager.getConnection(url, username, password);

                        // Handle delete action
                        String action = request.getParameter("action");
                        if ("delete".equals(action)) {
                            String rid = request.getParameter("rid");
                            String deleteQuery = "DELETE FROM request WHERE rid = ?";
                            pstmt = conn.prepareStatement(deleteQuery);
                            pstmt.setInt(1, Integer.parseInt(rid));
                            int rowsDeleted = pstmt.executeUpdate();

                            if (rowsDeleted > 0) {
                                out.println("<script>alert('Record deleted successfully!');</script>");
                            } else {
                                out.println("<script>alert('Failed to delete record.');</script>");
                            }
                        }

                        // Fetch data for the table
                        String query = "SELECT * FROM request";
                        pstmt = conn.prepareStatement(query);
                        rs = pstmt.executeQuery();

                        boolean hasRecords = false;
                        while (rs.next()) {
                            hasRecords = true;
                            int rid = rs.getInt("rid");
                            String roll = rs.getString("roll");
                            String bName = rs.getString("b_name");
                %>
                <tr>
                    <td><%= rid %></td>
                    <td><%= roll %></td>
                    <td><%= bName %></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="rid" value="<%= rid %>">
                            <button type="submit" class="btn return">Delete</button>
                        </form>
                    </td>
                </tr>
                <%
                        }

                        if (!hasRecords) {
                %>
                <tr>
                    <td colspan="4" class="no-records">No records found.</td>
                </tr>
                <%
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                %>
                <tr>
                    <td colspan="4" class="no-records">Error fetching data: <%= e.getMessage() %></td>
                </tr>
                <%
                    } finally {
                        if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
                        if (pstmt != null) try { pstmt.close(); } catch (SQLException ignore) {}
                        if (conn != null) try { conn.close(); } catch (SQLException ignore) {}
                    }
                %>
            </tbody>
        </table>
    </div>
</body>
</html>
