<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.temporal.ChronoUnit" %>
<%@ include file="header1.jsp" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h1, h2 {
            text-align: center;
            color: #006400;
        }
        .renew-btn, .submit-btn, .back-btn {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }
        .input-field{
            width: 95%;
            padding: 12px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fafafa;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        .renew-btn:hover, .submit-btn:hover, .back-btn:hover {
            opacity: 0.8;
            background-color: #004d00;
        }

        .renew-btn:focus, .submit-btn:focus, .back-btn:focus {
            outline: none;
            background-color: #004d00;
        }

        .renew-btn:active, .submit-btn:active, .back-btn:active {
            background-color: #003300;
        }

        .details {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .details div {
            margin-bottom: 10px;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #f0f0f0;
        }
        .button-container {
            text-align: right; /* Aligns the button to the right */
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <%
        try {
            String updateFineSql = "UPDATE s_book SET fine = GREATEST(DATEDIFF(CURDATE(), submit_date), 0) WHERE submit_date IS NOT NULL";
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");
            PreparedStatement pstmt = con.prepareStatement(updateFineSql);
            pstmt.executeUpdate();
            pstmt.close();
            con.close();
        } catch (Exception e) {
            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
        }

        String url = "jdbc:mysql://localhost:3306/library";
        String user = "sairam";
        String password = "charan";

        String rollNo = (String) session.getAttribute("rollNo");
        if (rollNo == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);

            // Student Details
            String studentSql = "SELECT * FROM students WHERE roll = ?";
            String countSql = "SELECT count(roll) FROM attendance WHERE roll = ?";
            PreparedStatement studentStmt = conn.prepareStatement(studentSql);
            studentStmt.setString(1, rollNo);
            ResultSet studentRs = studentStmt.executeQuery();

            if (studentRs.next()) {
                // Fetch student details
                out.println("<h1>Record of " + studentRs.getString("name") + " (" + rollNo + ")</h1>");
                out.println("<div class='details'>");
                out.println("<div><strong>Roll No:</strong> " + rollNo + "</div>");
                out.println("<div><strong>Name:</strong> " + studentRs.getString("name") + "</div>");
                out.println("<div><strong>Semester:</strong> " + studentRs.getInt("sem") + "</div>");
                out.println("<div><strong>Branch:</strong> " + studentRs.getString("branch") + "</div>");

                // Fetch attendance count
                PreparedStatement countStmt = conn.prepareStatement(countSql);
                countStmt.setString(1, rollNo);
                ResultSet countRs = countStmt.executeQuery();

                if (countRs.next()) {
                    int totalVisits = countRs.getInt(1); // Get the attendance count
                    out.println("<div><strong>Total Visits:</strong> " + totalVisits + "</div>");
                }
                out.println("<form action='Library-students.jsp' method='get'>");
                    out.println("<button type='submit' class='renew-btn'>");
                    out.println("<b>View Library Books</b>");
                    out.println("</button>");
                out.println("</form>");
                out.println("</div>");
            }

            // Borrowed Books
            String bookSql = "SELECT * FROM s_book WHERE roll_no = ?";
            PreparedStatement bookStmt = conn.prepareStatement(bookSql);
            bookStmt.setString(1, rollNo);
            ResultSet bookRs = bookStmt.executeQuery();
            out.println("<h2>Books Borrowed:</h2>");
            out.println("<table><tr><th>Book ID</th><th>Borrow Date</th><th>Submit Date</th><th>Fine</th><th>Renew</th></tr>");
            while (bookRs.next()) {
                out.println("<tr>");
                out.println("<td>" + bookRs.getString("id") + "</td>");
                out.println("<td>" + bookRs.getDate("borrow_date") + "</td>");
                out.println("<td>" + bookRs.getDate("submit_date") + "</td>");
                out.println("<td>" + bookRs.getInt("fine") + "</td>");

                // Check if the book is eligible for renewal
                int fine = bookRs.getInt("fine");
                int renewalCount = bookRs.getInt("renewal_count");

                if (fine > 0 || renewalCount == 1) {
                    out.println("<td><button class='renew-btn' onclick='alert(\"Renewal not allowed: Book already renewed once or fine exists\");'>Renew</button></td>");
                } else {
                    out.println("<td>");
                    out.println("<form method='post' style='display:inline;'>");
                    out.println("<input type='hidden' name='book_id' value='" + bookRs.getString("id") + "'>");
                    out.println("<input type='hidden' name='roll_no' value='" + rollNo + "'>");
                    out.println("<button type='submit' class='renew-btn'>Renew</button>");
                    out.println("</form>");
                    out.println("</td>");
                }
                out.println("</tr>");
            }
            out.println("</table>");

            // Borrowing History
            String historySql = "SELECT * FROM borrowing_history WHERE roll_no = ?";
            PreparedStatement historyStmt = conn.prepareStatement(historySql);
            historyStmt.setString(1, rollNo);
            ResultSet historyRs = historyStmt.executeQuery();
            out.println("<h2>Borrowing History:</h2>");
            out.println("<table><tr><th>Book ID</th><th>Event Type</th><th>Transaction Date</th></tr>");
            while (historyRs.next()) {
                out.println("<tr>");
                out.println("<td>" + historyRs.getString("book_id") + "</td>");
                out.println("<td>" + historyRs.getString("event_type") + "</td>");
                out.println("<td>" + historyRs.getDate("transaction_date") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            // Fine Payments
            String paymentSql = "SELECT * FROM fine_payments WHERE roll_no = ?";
            PreparedStatement paymentStmt = conn.prepareStatement(paymentSql);
            paymentStmt.setString(1, rollNo);
            ResultSet paymentRs = paymentStmt.executeQuery();
            out.println("<h2>Fine Payment History:</h2>");
            out.println("<table><tr><th>Book ID</th><th>Fine Amount</th><th>Payment Date</th></tr>");
            while (paymentRs.next()) {
                out.println("<tr>");
                out.println("<td>" + paymentRs.getString("book_id") + "</td>");
                out.println("<td>" + paymentRs.getInt("fine_amount") + "</td>");
                out.println("<td>" + paymentRs.getDate("payment_date") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            // Handle renewal request
            if ("POST".equalsIgnoreCase(request.getMethod())) {
                String bookId = request.getParameter("book_id");
                String rollNoParam = request.getParameter("roll_no");

                // Fetch the fine and renewal count
                String selectSql = "SELECT fine, renewal_count FROM s_book WHERE roll_no = ? AND id = ?";
                PreparedStatement selectStmt = conn.prepareStatement(selectSql);
                selectStmt.setString(1, rollNoParam);
                selectStmt.setString(2, bookId);
                ResultSet selectRs = selectStmt.executeQuery();

                if (selectRs.next()) {
                    int fine = selectRs.getInt("fine");
                    int renewalCount = selectRs.getInt("renewal_count");

                    // If fine > 0 or renewal count is 1, do not allow renewal
                    if (fine > 0 || renewalCount == 1) {
                        out.println("<script>alert('You cannot renew this book.');</script>");
                    } else {
                        // Renew the book
                        LocalDate currentDate = LocalDate.now();
                        LocalDate newSubmitDate = currentDate.plusMonths(1);

                        // Update s_book
                        String updateSql = "UPDATE s_book SET borrow_date = ?, submit_date = ?, fine = ?, renewal_count = ? WHERE roll_no = ? AND id = ?";
                        PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                        updateStmt.setDate(1, Date.valueOf(currentDate));
                        updateStmt.setDate(2, Date.valueOf(newSubmitDate));
                        updateStmt.setInt(3, 0); // Reset fine
                        updateStmt.setInt(4, renewalCount + 1); // Increment renewal count
                        updateStmt.setString(5, rollNoParam);
                        updateStmt.setString(6, bookId);
                        updateStmt.executeUpdate();

                        // Insert into borrowing_history for renewal
                        String insertHistorySql = "INSERT INTO borrowing_history (roll_no, book_id, event_type, transaction_date) VALUES (?, ?, ?, ?)";
                        PreparedStatement insertHistoryStmt = conn.prepareStatement(insertHistorySql);
                        insertHistoryStmt.setString(1, rollNoParam);
                        insertHistoryStmt.setString(2, bookId);
                        insertHistoryStmt.setString(3, "renew");
                        insertHistoryStmt.setDate(4, Date.valueOf(currentDate));
                        insertHistoryStmt.executeUpdate();

                        out.println("<script>alert('Book renewed successfully!');</script>");
                    }
                }
            }

            // Book Request Handling
            if ("POST".equalsIgnoreCase(request.getMethod())) {
                String bookName = request.getParameter("book_name");

                // Insert book request into the 'request' table
                String requestSql = "INSERT INTO request (roll, b_name) VALUES (?, ?)";
                PreparedStatement requestStmt = conn.prepareStatement(requestSql);
                requestStmt.setString(1, rollNo);
                requestStmt.setString(2, bookName);
                requestStmt.executeUpdate();

                out.println("<script>alert('Book request submitted successfully!');</script>");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
        }
        %>

        <!-- Book Request Form -->
        <h2>Request a Book</h2>
        <form method="post">
            <input type="text" name="book_name" class="input-field" placeholder="Book Name" required><br><br>
            <input type="submit" value="Submit Request" class="submit-btn">
        </form>

    </div>
</body>
</html>
