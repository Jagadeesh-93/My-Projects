<!-- header.jsp -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PVPSIT Header</title>
    <style>
        /* Reset styles */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        /* Header styles */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 20px 30px;
            border-bottom: 2px solid #ddd;
        }

        .logo-section {
            display: flex;
            align-items: center;
        }

        .logo-section img {
            height: 120px; 
            margin-right: 15px;
        }

        .institute-details {
            line-height: 1.4;
        }

        .institute-details h1 {
            font-size: 1.8rem;
            margin: 0;
            color: #006400; 
            font-weight: bold;
        }

        .institute-details h2 {
            font-size: 1.2rem;
            margin: 5px 0;
            font-style: italic;
            color: #333;
        }

        .institute-details p {
            font-size: 0.9rem;
            margin: 3px 0;
            color: #555;
        }

        .badge-section {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .badge-section img {
            height: 80px;
        }

        .badge-section .years-badge img {
            height: 100px;
        }

        .eamcet-code {
            font-size: 1.1rem;
            color: #006400;
            font-weight: bold;
            margin-top: 10px;
            text-align: center;
        }

        /* Login Button styles */
        .login-button {
            background-color: #dfc9c9;
            color: #030303;
            padding: 10px 20px;
            font-size: 1rem;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            position: absolute;
            top: 20px;
            right: 30px;
        }

        .login-button:hover {
            background-color: #6b706b;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-section">
            <a href="index.html">
                <img src="images/logo.png" alt="Institute Logo"></a>
            <div class="institute-details">
                <h1>Prasad V. Potluri Siddhartha Institute of Technology</h1>
                <h2>(Autonomous)</h2>
                <p>Approved by AICTE and Affiliated to JNTU Kakinada</p>
                <p>Sponsored by: Siddhartha Academy of General and Technical Education, Vijayawada</p>
            </div>
        </div>

        <div class="badge-section">
            <div class="eamcet-code">
                <p>EAMCET Code: PPSV</p>
            </div>
        </div>
    </header>

    
</body>
</html>
