<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Website</title>
    <style>
        /* Basic styling */
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4; /* Light background for better contrast */
    color: #333; /* Darker text for readability */
}

/* Navbar styling */
.navbar {
    background-color: #006400; /* Green navbar */
    overflow: hidden;
    padding: 10px 0;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    border-bottom: 2px solid #004d00; /* Darker border for futuristic feel */
}

/* Navbar links */
.navbar a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 20px;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    letter-spacing: 1px; /* Slight spacing for modern look */
    text-transform: uppercase; /* Capitalize for futuristic touch */
    transition: all 0.3s ease;
}

.navbar a:hover {
    background-color: #ffffff; /* White background on hover */
    color: black; /* Black text on hover */
    transform: scale(1.05); /* Subtle scaling effect for hover */
}

/* Dropdown styling */
.dropdown {
    float: left;
    overflow: hidden;
}

/* Dropdown button */
.dropdown .dropbtn {
    font-size: 16px;
    border: none;
    outline: none;
    color: white;
    padding: 14px 20px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
    cursor: pointer;
    text-transform: uppercase; /* Capitalized text */
    letter-spacing: 1px;
    transition: all 0.3s ease;
}

.dropdown .dropbtn:hover {
    background-color: #ffffff; /* White background on hover */
    color: black; /* Black text on hover */
    transform: scale(1.05); /* Subtle scaling effect for hover */
}

/* Dropdown content */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #08b708; /* Light green */
    min-width: 200px;
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
    z-index: 1;
    border-radius: 10px; /* More rounded for a sleek look */
    opacity: 0;
    transition: opacity 0.3s ease;
}

.dropdown-content a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 20px;
    text-decoration: none;
    font-weight: bold;
    transition: all 0.3s ease;
}

.dropdown-content a:hover {
    background-color: #ffffff; /* White background on hover */
    color: black; /* Black text on hover */
    transform: scale(1.05); /* Subtle scaling effect for hover */
}

.dropdown:hover .dropdown-content {
    display: block; /* Show the dropdown */
    opacity: 1; /* Fade-in effect */
}

/* Styling for the iframe */
iframe {
    width: 100%;
    height: 600px;
    border: none;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1); /* Shadow for depth */
    border-radius: 10px; /* Rounded corners */
}

    </style>
</head>
<body>

<%@ include file="header1.jsp" %>

<div class="navbar">
    <a href="libraryData.jsp" target="contentFrame">Books</a>
    <div class="dropdown">
        <button class="dropbtn">Attendance</button>
        <div class="dropdown-content">
            <a href="attendance.jsp" target="contentFrame">Attendance Record</a>
            <a href="addattendance.jsp" target="contentFrame">Add Attendance</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">Student-Center</button>
        <div class="dropdown-content">
            <a href="addsbook.jsp" target="contentFrame">Add Book</a>
            <a href="sbdata.jsp" target="contentFrame">Student Data</a>
            <a href="finepending.jsp" target="contentFrame">Fines</a>
            <a href="FilterStats.jsp" target="contentFrame">Stats & Insights</a>
            <a href="history.jsp" target="contentFrame">History</a>
            <a href="request.jsp" target="contentFrame">Book Request</a>
        </div>
    </div>
    <a href="payments.jsp" target="contentFrame">Payments</a>
    <a href="addBook.jsp" target="contentFrame">Add New Book</a>
</div>

<!-- Embed an iframe to load the content -->
<iframe name="contentFrame" id="contentFrame" src="libraryData.jsp"></iframe>

</body>
</html>
