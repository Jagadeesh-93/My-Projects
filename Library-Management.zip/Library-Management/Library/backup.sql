-- MySQL dump 10.13  Distrib 5.5.41, for Win64 (x86)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	5.5.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `roll` char(10) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`roll`,`date_time`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`roll`) REFERENCES `students` (`roll`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES ('22501A0191','2025-01-10 19:14:24'),('22501A0191','2025-01-18 19:20:40'),('22501A01C4','2025-01-28 09:09:09'),('22501A02A2','2025-01-30 09:06:22'),('22501A0394','2025-01-31 00:23:02'),('22501A03D5','2025-01-10 19:14:49'),('22501A03D5','2025-01-18 19:21:03'),('22501A0492','2025-01-01 19:12:10'),('22501A04A3','2025-01-01 19:12:28'),('22501A04A3','2025-01-28 09:09:04'),('22501A04A3','2025-01-30 09:06:17'),('22501A04B4','2025-01-01 19:12:17'),('22501A0591','2025-01-18 19:19:30'),('22501A0591','2025-01-28 09:09:14'),('22501A05A2','2025-01-27 09:10:04'),('22501A05C4','2025-01-18 19:19:05'),('22501A05D5','2025-01-01 19:11:50'),('22501A1292','2025-01-18 19:53:55'),('22501A1292','2025-01-31 00:01:19'),('22501A1293','2025-01-31 00:02:11'),('22501A1295','2025-01-01 07:20:35'),('22501A1295','2025-12-25 07:22:32'),('22501A12A3','2025-01-27 09:10:09'),('22501A12A3','2025-01-28 09:08:18'),('22501A12A3','2025-01-31 00:05:14'),('22501A12A6','2025-01-01 19:11:04'),('22501A12B5','2025-01-01 19:10:27'),('22501A12C8','2025-01-01 19:11:31'),('22501A12D9','2025-01-27 09:10:12'),('22501A12D9','2025-01-28 09:09:00'),('23501A01B8','2025-01-10 19:14:32'),('23501A01C9','2025-01-18 19:20:48'),('23501A01C9','2025-01-27 09:10:16'),('23501A01D0','2025-01-27 09:10:20'),('23501A01D0','2025-01-28 09:08:22'),('23501A01D0','2025-01-29 09:05:39'),('23501A02A7','2025-01-10 19:14:41'),('23501A02B8','2025-01-18 19:20:56'),('23501A02C9','2025-01-28 09:09:18'),('23501A03D0','2025-01-28 09:08:56'),('23501A05A7','2025-01-10 19:13:55'),('23501A05B8','2025-01-28 09:08:26'),('23501A05B8','2025-01-31 00:16:50'),('23501A05D0','2025-01-01 19:11:59'),('23501A05D0','2025-01-28 09:08:30'),('23501A05D0','2025-01-29 09:05:11'),('23501A1291','2025-01-18 19:19:50'),('23501A1298','2025-01-29 09:05:15'),('23501A12A2','2025-01-01 19:10:39'),('23501A12A9','2025-01-29 09:05:19'),('23501A12A9','2025-01-31 00:17:54'),('23501A12B0','2025-01-10 19:13:31'),('24501A0192','2025-01-29 09:05:35'),('24501A01B4','2025-01-31 00:18:56'),('24501A01C5','2025-01-28 09:08:50'),('24501A01C5','2025-01-29 09:05:23'),('24501A02D6','2025-01-28 09:08:33'),('24501A03D6','2025-01-29 09:05:27'),('24501A0592','2025-01-10 19:13:49'),('24501A05A3','2025-01-18 19:19:16'),('24501A05D6','2025-01-10 19:14:14'),('24501A05D6','2025-01-18 19:19:23'),('24501A12A1','2025-01-18 19:19:41'),('24501A12A4','2025-01-01 19:11:39'),('24501A12B5','2025-01-28 09:08:41'),('24501A12C3','2025-01-29 09:05:31'),('24501A12D4','2025-01-01 19:10:50'),('24501A12D7','2025-01-10 19:13:41'),('24501A12D7','2025-01-28 09:08:46');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `sem` int(11) DEFAULT '0',
  `type` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (100001,'Engineering Mathematics - I','B.S. Grewal',1,'Curriculum',10,10),(100002,'Engineering Physics','H.K. Malik',1,'Curriculum',4,8),(100003,'Engineering Chemistry','Jain & Jain',1,'Curriculum',7,7),(100004,'Basic Electrical Engineering','D.P. Kothari',2,'Curriculum',4,6),(100005,'Programming in C','E. Balagurusamy',2,'Curriculum',9,12),(100006,'Data Structures and Algorithms','Sartaj Sahni',3,'Curriculum',8,10),(100007,'Digital Logic Design','M. Morris Mano',3,'Curriculum',5,8),(100008,'Signals and Systems','Alan V. Oppenheim',3,'Curriculum',5,6),(100009,'Computer Networks','Andrew S. Tanenbaum',5,'Curriculum',10,10),(100010,'Operating Systems','Abraham Silberschatz',5,'Curriculum',8,8),(100011,'The Phoenix Project','Gene Kim',NULL,'Novel',4,5),(100012,'Zero to One','Peter Thiel',NULL,'Novel',7,7),(100013,'The Goal','Eliyahu M. Goldratt',NULL,'Novel',5,6),(100014,'Hackers & Painters','Paul Graham',NULL,'Novel',1,4),(100015,'The Lean Startup','Eric Ries',NULL,'Novel',6,9),(100016,'Artificial Intelligence','Stuart Russell',7,'HStudy',8,10),(100017,'Cloud Computing','Rajkumar Buyya',7,'HStudy',8,8),(100018,'Internet of Things (IoT)','Arshdeep Bahga',8,'HStudy',5,6),(100019,'Machine Learning','Tom M. Mitchell',8,'HStudy',4,7),(100020,'Software Engineering','Ian Sommerville',8,'HStudy',9,9),(100021,'IEEE Spectrum','IEEE',NULL,'Magazine',10,10),(100022,'Wired','Cond‚ Nast',NULL,'Magazine',5,7),(100023,'MIT Technology Review','MIT Press',NULL,'Magazine',1,6),(100024,'Electrical Engineering Handbook','Richard Dorf',NULL,'Handbook',1,5),(100025,'Mechanical Engineering Handbook','Frank Kreith',NULL,'Handbook',1,4),(100026,'Civil Engineering Reference Manual','Michael Lindeburg',NULL,'Handbook',6,6),(100027,'Computer Science Guide','S. Chand',NULL,'Guide',8,8),(100028,'Elon Musk: Tesla, SpaceX, and the Quest for a Fantastic Future','Ashlee Vance',NULL,'Biography',4,7),(100029,'Steve Jobs','Walter Isaacson',NULL,'Biography',3,6),(100030,'Final Year Project Handbook','John Doe',NULL,'Project',8,9);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrowing_history`
--

DROP TABLE IF EXISTS `borrowing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrowing_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `roll_no` varchar(20) NOT NULL,
  `book_id` int(11) NOT NULL,
  `event_type` varchar(20) NOT NULL,
  `transaction_date` date NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `roll_no` (`roll_no`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `borrowing_history_ibfk_1` FOREIGN KEY (`roll_no`) REFERENCES `students` (`roll`),
  CONSTRAINT `borrowing_history_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrowing_history`
--

LOCK TABLES `borrowing_history` WRITE;
/*!40000 ALTER TABLE `borrowing_history` DISABLE KEYS */;
INSERT INTO `borrowing_history` VALUES (1,'22501A12A3',100005,'borrow','2025-01-18'),(2,'24501A01B4',100004,'borrow','2025-01-18'),(3,'23501A02A7',100016,'borrow','2025-01-18'),(4,'22501A12A3',100005,'renew','2025-01-30'),(5,'23501A12A9',100002,'borrow','2025-01-30'),(6,'24501A01C5',100013,'borrow','2025-01-30'),(7,'24501A03C5',100024,'borrow','2025-01-30'),(8,'24501A03B4',100029,'borrow','2025-01-11'),(9,'23501A12A2',100025,'borrow','2025-01-11'),(10,'23501A05B8',100014,'borrow','2025-01-11'),(11,'23501A03C9',100005,'borrow','2025-01-13'),(12,'23501A0596',100006,'borrow','2025-01-13'),(13,'23501A12A2',100019,'borrow','2025-01-13'),(14,'24501A02C5',100029,'borrow','2025-01-13'),(15,'24501A05A3',100030,'borrow','2025-01-16'),(16,'24501A01D6',100023,'borrow','2025-01-16'),(17,'23501A12A9',100024,'borrow','2025-01-16'),(18,'23501A03A7',100023,'borrow','2025-01-16'),(19,'23501A03C9',100018,'borrow','2025-01-19'),(20,'24501A01D6',100006,'borrow','2025-01-19'),(21,'23501A12D2',100023,'borrow','2025-01-19'),(22,'23501A12C1',100028,'borrow','2025-01-19'),(23,'22501A02B3',100014,'borrow','2025-01-19'),(24,'22501A01C4',100015,'borrow','2025-01-19'),(25,'22501A0291',100022,'borrow','2025-01-19'),(26,'22501A03A2',100024,'borrow','2025-01-21'),(27,'22501A02C4',100007,'borrow','2025-01-26'),(28,'22501A0394',100005,'borrow','2025-01-26'),(29,'22501A0394',100011,'borrow','2025-01-26'),(30,'22501A05B3',100023,'borrow','2025-01-26'),(31,'22501A05B3',100025,'borrow','2025-01-27'),(32,'23501A12A9',100029,'borrow','2025-01-28'),(33,'23501A1298',100025,'borrow','2025-01-28'),(34,'24501A0292',100002,'borrow','2025-01-29'),(35,'24501A03C5',100007,'borrow','2025-01-29'),(36,'24501A12B5',100016,'borrow','2025-01-29'),(37,'24501A12D7',100019,'borrow','2025-01-29'),(38,'24501A05A3',100028,'borrow','2025-01-29'),(39,'24501A05A3',100028,'renew','2025-01-30'),(40,'22501A03A2',100024,'renew','2025-01-30'),(41,'22501A1293',100002,'borrow','2025-01-01'),(42,'22501A1295',100015,'borrow','2025-01-01'),(43,'22501A1295',100019,'borrow','2025-12-25'),(44,'22501A1295',100002,'borrow','2024-12-31'),(45,'22501A1295',100007,'borrow','2025-12-27'),(46,'23501A1298',100022,'borrow','2024-11-30'),(47,'23501A1298',100022,'renew','2025-01-31'),(48,'24501A1293',100008,'borrow','2024-11-27'),(49,'23501A05D0',100004,'borrow','2024-11-27'),(50,'23501A0296',100015,'borrow','2024-11-27'),(51,'23501A1298',100028,'borrow','2024-11-30'),(52,'23501A1298',100014,'borrow','2024-11-25'),(53,'23501A1298',100024,'borrow','2024-11-21'),(54,'23501A1298',100023,'borrow','2024-11-21');
/*!40000 ALTER TABLE `borrowing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fine_payments`
--

DROP TABLE IF EXISTS `fine_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fine_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roll_no` varchar(20) NOT NULL,
  `book_id` int(11) NOT NULL,
  `fine_amount` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roll_no` (`roll_no`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `fine_payments_ibfk_1` FOREIGN KEY (`roll_no`) REFERENCES `students` (`roll`),
  CONSTRAINT `fine_payments_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fine_payments`
--

LOCK TABLES `fine_payments` WRITE;
/*!40000 ALTER TABLE `fine_payments` DISABLE KEYS */;
INSERT INTO `fine_payments` VALUES (1,'23501A1298',100022,32,'2025-01-31');
/*!40000 ALTER TABLE `fine_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `roll` varchar(20) DEFAULT NULL,
  `b_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rid`),
  KEY `roll` (`roll`),
  CONSTRAINT `request_ibfk_1` FOREIGN KEY (`roll`) REFERENCES `students` (`roll`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (1,'22501A1277','BAGAVAT GEETHA'),(4,'23501A02A7','Modren Web Application'),(7,'22501A12A3','Bleach');
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_book`
--

DROP TABLE IF EXISTS `s_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_book` (
  `roll_no` char(10) NOT NULL,
  `id` int(11) NOT NULL,
  `borrow_date` date NOT NULL,
  `submit_date` date DEFAULT NULL,
  `fine` int(11) DEFAULT '0',
  `renewal_count` int(11) DEFAULT '0',
  PRIMARY KEY (`roll_no`,`id`),
  KEY `id` (`id`),
  CONSTRAINT `s_book_ibfk_1` FOREIGN KEY (`roll_no`) REFERENCES `students` (`roll`) ON DELETE CASCADE,
  CONSTRAINT `s_book_ibfk_2` FOREIGN KEY (`id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_book`
--

LOCK TABLES `s_book` WRITE;
/*!40000 ALTER TABLE `s_book` DISABLE KEYS */;
INSERT INTO `s_book` VALUES ('22501A01C4',100015,'2025-01-19','2025-02-19',0,0),('22501A0291',100022,'2025-01-19','2025-02-19',0,0),('22501A02B3',100014,'2025-01-19','2025-02-19',0,0),('22501A02C4',100007,'2025-01-26','2025-02-26',0,0),('22501A0394',100005,'2025-01-26','2025-02-26',0,0),('22501A0394',100011,'2025-01-26','2025-02-26',0,0),('22501A03A2',100024,'2025-01-30','2025-02-28',0,1),('22501A05B3',100023,'2025-01-26','2025-02-26',0,0),('22501A05B3',100025,'2025-01-27','2025-02-27',0,0),('22501A1293',100002,'2025-01-01','2025-02-01',0,0),('22501A1295',100002,'2024-12-31','2025-01-31',0,0),('22501A1295',100007,'2025-12-27','2026-01-27',0,0),('22501A1295',100015,'2025-01-01','2025-02-01',0,0),('22501A1295',100019,'2025-12-25','2026-01-25',0,0),('22501A12A3',100005,'2025-01-30','2025-02-28',0,1),('23501A0296',100015,'2024-11-27','2024-12-27',35,0),('23501A02A7',100016,'2025-01-18','2025-02-18',0,0),('23501A03A7',100023,'2025-01-16','2025-02-16',0,0),('23501A03C9',100005,'2025-01-13','2025-02-13',0,0),('23501A03C9',100018,'2025-01-19','2025-02-19',0,0),('23501A0596',100006,'2025-01-13','2025-02-13',0,0),('23501A05B8',100014,'2025-01-11','2025-02-11',0,0),('23501A05D0',100004,'2024-11-27','2024-12-27',35,0),('23501A1298',100014,'2024-11-25','2024-12-25',37,0),('23501A1298',100022,'2025-01-31','2025-02-28',0,1),('23501A1298',100023,'2024-11-21','2024-12-21',41,0),('23501A1298',100024,'2024-11-21','2024-12-21',41,0),('23501A1298',100025,'2025-01-28','2025-02-28',0,0),('23501A1298',100028,'2024-11-30','2024-12-30',32,0),('23501A12A2',100019,'2025-01-13','2025-02-13',0,0),('23501A12A2',100025,'2025-01-11','2025-02-11',0,0),('23501A12A9',100002,'2025-01-30','2025-02-28',0,0),('23501A12A9',100024,'2025-01-16','2025-02-16',0,0),('23501A12A9',100029,'2025-01-28','2025-02-28',0,0),('23501A12C1',100028,'2025-01-19','2025-02-19',0,0),('23501A12D2',100023,'2025-01-19','2025-02-19',0,0),('24501A01B4',100004,'2025-01-18','2025-02-18',0,0),('24501A01C5',100013,'2025-01-30','2025-02-28',0,0),('24501A01D6',100006,'2025-01-19','2025-02-19',0,0),('24501A01D6',100023,'2025-01-16','2025-02-16',0,0),('24501A0292',100002,'2025-01-29','2025-02-28',0,0),('24501A02C5',100029,'2025-01-13','2025-02-13',0,0),('24501A03B4',100029,'2025-01-11','2025-02-11',0,0),('24501A03C5',100007,'2025-01-29','2025-02-28',0,0),('24501A03C5',100024,'2025-01-30','2025-02-28',0,0),('24501A05A3',100028,'2025-01-30','2025-02-28',0,1),('24501A05A3',100030,'2025-01-16','2025-02-16',0,0),('24501A1293',100008,'2024-11-27','2024-12-27',35,0),('24501A12B5',100016,'2025-01-29','2025-02-28',0,0),('24501A12D7',100019,'2025-01-29','2025-02-28',0,0);
/*!40000 ALTER TABLE `s_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `roll` char(10) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `branch` varchar(5) DEFAULT NULL,
  `password` varchar(255) NOT NULL DEFAULT 'pvpsit',
  `count` int(11) DEFAULT '0',
  PRIMARY KEY (`roll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('22501A0191','Arjun Tiwari',6,'CIVIL','pvpsit',0),('22501A0192','Arun Tiwari',6,'CIVIL','pvpsit',0),('22501A01A2','Deepak Chatterjee',6,'CIVIL','pvpsit',0),('22501A01B3','Rajesh Yadav',6,'CIVIL','pvpsit',0),('22501A01C4','Surya Patel',6,'CIVIL','pvpsit',1),('22501A01D5','Gaurav Reddy',6,'CIVIL','pvpsit',0),('22501A0291','Amit Trivedi',6,'MECH','pvpsit',1),('22501A0293','Deepak Chatterjee',6,'MECH','pvpsit',0),('22501A02A2','Prashant Verma',6,'MECH','pvpsit',0),('22501A02B3','Karthik Iyer',6,'MECH','pvpsit',1),('22501A02C4','Suresh Pillai',6,'MECH','pvpsit',1),('22501A02D5','Manoj Gupta',6,'MECH','pvpsit',0),('22501A0391','Priya Aggarwal',6,'MBA','pvpsit',0),('22501A0394','Pallavi Chaturvedi',6,'MBA','pvpsit',2),('22501A03A2','Rohit Bansal',6,'MBA','pvpsit',1),('22501A03B3','Swati Deshmukh',6,'MBA','pvpsit',0),('22501A03C4','Akhil Menon',6,'MBA','pvpsit',0),('22501A03D5','Jaya Bhardwaj',6,'MBA','pvpsit',0),('22501A0492','Swati Sharma',6,'ECE','pvpsit',0),('22501A04A3','Abhay Choudhary',6,'ECE','pvpsit',0),('22501A04B4','Neha Bajaj',6,'ECE','pvpsit',0),('22501A04C5','Mohit Joshi',6,'ECE','pvpsit',0),('22501A04D6','Ritu Sinha',6,'ECE','pvpsit',0),('22501A0591','Ramesh Pillai',6,'EEE','pvpsit',0),('22501A05A2','Ujjwal Saxena',6,'EEE','pvpsit',0),('22501A05B3','Megha Aggarwal',6,'EEE','pvpsit',2),('22501A05C4','Suraj Menon',6,'EEE','pvpsit',0),('22501A05D5','Ayesha Khan',6,'EEE','pvpsit',0),('22501A1277','Manohar',5,'IT','pvpsit',3),('22501A1285','jeevan mia',5,'IT','pvpsit',2),('22501A1292','charan',5,'IT','Welcome#01',0),('22501A1293','jagadeesh',5,'IT','pvpsit',3),('22501A1295','Ritika Sharma',6,'IT','pvpsit',4),('22501A12A3','kiran',5,'IT','pvpsit',4),('22501A12A6','Harsh Raj',6,'IT','pvpsit',0),('22501A12B5','Sohan Kumar',6,'CSE','pvpsit',0),('22501A12B7','Sanya Kapoor',6,'IT','pvpsit',0),('22501A12C7','Ishita Verma',6,'CSE','pvpsit',0),('22501A12C8','Yash Pandey',6,'IT','pvpsit',0),('22501A12D0','Tanya Mishra',6,'IT','pvpsit',0),('22501A12D9','Rohan Gupta',6,'CSE','pvpsit',0),('23501A0196','Vikram Singh',4,'CIVIL','pvpsit',0),('23501A01A7','Megha Rao',4,'CIVIL','pvpsit',0),('23501A01B8','Aniket Nair',4,'CIVIL','pvpsit',0),('23501A01C9','Pooja Kapoor',4,'CIVIL','pvpsit',0),('23501A01D0','Dinesh Chauhan',4,'CIVIL','pvpsit',0),('23501A0296','Shweta Kumari',4,'MECH','pvpsit',1),('23501A02A7','Siddharth Reddy',4,'MECH','pvpsit',1),('23501A02B8','Rohan Das',4,'MECH','pvpsit',0),('23501A02C9','Sanjana Naik',4,'MECH','pvpsit',0),('23501A02D0','Mahesh Rao',4,'MECH','pvpsit',0),('23501A0396','Varun Malhotra',4,'MBA','pvpsit',0),('23501A03A7','Meera Saxena',4,'MBA','pvpsit',1),('23501A03B8','Anil Kapoor',4,'MBA','pvpsit',0),('23501A03C9','Shraddha Joshi',4,'MBA','pvpsit',2),('23501A03D0','Rajesh Khanna',4,'MBA','pvpsit',0),('23501A0596','Ritik Reddy',4,'EEE','pvpsit',1),('23501A05A7','Sonia Verma',4,'EEE','pvpsit',0),('23501A05B8','Naman Shetty',4,'EEE','pvpsit',1),('23501A05C9','Shruti Jha',4,'EEE','pvpsit',0),('23501A05D0','Gautam Bansal',4,'EEE','pvpsit',1),('23501A1291','Kavya Nair',4,'CSE','pvpsit',0),('23501A1298','Rajeev Bhat',4,'IT','pvpsit',6),('23501A12A2','Varun Malhotra',4,'CSE','pvpsit',2),('23501A12A9','Sakshi Jain',4,'IT','pvpsit',3),('23501A12B0','Vivek Kumar',4,'IT','pvpsit',0),('23501A12B3','Diya Patel',4,'CSE','pvpsit',0),('23501A12C1','Anjali Nanda',4,'IT','pvpsit',1),('23501A12C4','Rahul Mehta',4,'CSE','pvpsit',0),('23501A12D2','Dhruv Choudhary',4,'IT','pvpsit',1),('23501A12D5','Sneha Iyer',4,'CSE','pvpsit',0),('24501A0192','Sandeep Sharma',2,'CIVIL','pvpsit',0),('24501A01A3','Rekha Menon',2,'CIVIL','pvpsit',0),('24501A01B4','Yashwant Desai',2,'CIVIL','pvpsit',1),('24501A01C5','Tanvi Shetty',2,'CIVIL','pvpsit',1),('24501A01D6','Lokesh Joshi',2,'CIVIL','pvpsit',2),('24501A0292','Vinod Patel',2,'MECH','pvpsit',1),('24501A02A3','Kavita Sharma',2,'MECH','pvpsit',0),('24501A02B4','Nitin Choudhary',2,'MECH','pvpsit',0),('24501A02C5','Sneha Kulkarni',2,'MECH','pvpsit',1),('24501A02D6','Bharath Singh',2,'MECH','pvpsit',0),('24501A0392','Sonali Iyer',2,'MBA','pvpsit',0),('24501A03A3','Nikhil Nanda',2,'MBA','pvpsit',0),('24501A03B4','Sanya Choudhary',2,'MBA','pvpsit',1),('24501A03C5','Tarun Gupta',2,'MBA','pvpsit',2),('24501A03D6','Anusha Reddy',2,'MBA','pvpsit',0),('24501A0592','Vinay Gupta',2,'EEE','pvpsit',0),('24501A05A3','Ishaan Pandey',2,'EEE','pvpsit',2),('24501A05B4','Nidhi Kapoor',2,'EEE','pvpsit',0),('24501A05C5','Saurabh Mehta',2,'EEE','pvpsit',0),('24501A05D6','Kiran Chauhan',2,'EEE','pvpsit',0),('24501A1290','Aditya Rao',2,'CSE','pvpsit',0),('24501A1293','Manish Tiwari',2,'IT','pvpsit',1),('24501A12A1','Simran Kaur',2,'CSE','pvpsit',0),('24501A12A4','Surbhi Singh',2,'IT','pvpsit',0),('24501A12B2','Neeraj Joshi',2,'CSE','pvpsit',0),('24501A12B5','Amit Yadav',2,'IT','pvpsit',1),('24501A12C3','Pooja Singh',2,'CSE','pvpsit',0),('24501A12C6','Priya Shah',2,'IT','pvpsit',0),('24501A12D4','Arjun Das',2,'CSE','pvpsit',0),('24501A12D7','Nishant Goyal',2,'IT','pvpsit',1),('pvpsituser','ADMIN',0,'IT','Getout#01',0);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-31  7:44:19
