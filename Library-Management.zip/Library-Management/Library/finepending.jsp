<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students with Fines</title>
    <style>
        /* Add the same styles from the previous page here for consistency */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-top: 30px;
        }
        form {
            text-align: center;
            margin: 20px;
        }
        select, input[type="submit"] {
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .error-message {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>
    <h1>Students with Fines</h1>

    <!-- Filter Form -->
    <form method="get" action="finepending.jsp">
        <label for="branch">Branch:</label>
        <select id="branch" name="branch">
            <option value="">All Branches</option>
            <option value="IT">IT</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="EEE">EEE</option>
            <option value="MECH">MECH</option>
            <option value="CIVIL">CIVIL</option>
        </select>

        <label for="sem">Semester:</label>
        <select id="sem" name="sem">
            <option value="">All Semesters</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
        </select>

        <input type="submit" value="Filter Records">
    </form>

    <%
        String selectedBranch = request.getParameter("branch");
        String selectedSem = request.getParameter("sem");

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

            // Build the query dynamically based on selected filters
            StringBuilder query = new StringBuilder(
                "SELECT s.roll, s.name, s.branch, s.sem, sb.fine " +
                "FROM students s " +
                "JOIN s_book sb ON s.roll = sb.roll_no " +  // use s.roll instead of s.roll_no
                "WHERE sb.fine > 0"
            );

            if (selectedBranch != null && !selectedBranch.isEmpty()) {
                query.append(" AND s.branch = ?");
            }
            if (selectedSem != null && !selectedSem.isEmpty()) {
                query.append(" AND s.sem = ?");
            }

            stmt = conn.prepareStatement(query.toString());

            int paramIndex = 1;
            if (selectedBranch != null && !selectedBranch.isEmpty()) {
                stmt.setString(paramIndex++, selectedBranch);
            }
            if (selectedSem != null && !selectedSem.isEmpty()) {
                stmt.setInt(paramIndex++, Integer.parseInt(selectedSem));
            }

            rs = stmt.executeQuery();

            // Check if there are any records
            if (!rs.isBeforeFirst()) {
    %>
                <p class="error-message">No students with fines found!</p>
    <%
            } else {
    %>
                <table>
                    <thead>
                        <tr>
                            <th>Roll Number</th>
                            <th>Name</th>
                            <th>Branch</th>
                            <th>Semester</th>
                            <th>Fine Amount</th>
                        </tr>
                    </thead>
                    <tbody>
    <%
                // Loop through the result set and display the records
                while (rs.next()) {
                    String rollNo = rs.getString("roll");
                    String name = rs.getString("name");
                    String branch = rs.getString("branch");
                    int sem = rs.getInt("sem");
                    int fine = rs.getInt("fine");
    %>
                        <tr>
                            <td><%= rollNo %></td>
                            <td><%= name %></td>
                            <td><%= branch %></td>
                            <td><%= sem %></td>
                            <td><%= fine %></td>
                        </tr>
    <%
                }
    %>
                    </tbody>
                </table>
    <%
            }
        } catch (Exception e) {
            out.println("<p class='error-message'>Error: " + e.getMessage() + "</p>");
            e.printStackTrace();
        } finally {
            // Close database resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    %>
</body>
</html>
