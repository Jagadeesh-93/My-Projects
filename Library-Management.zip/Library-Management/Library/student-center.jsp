<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Center</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        h2 {
            color: #555;
            margin-top: 20px;
            text-align: left;
        }

        ul {
            list-style-type: disc;
            margin-left: 20px;
        }

        ul li {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f0f0f0;
            border-radius: 5px;
        }

        ul li:hover {
            background-color: #e0e0e0;
        }
.back-btn {
    padding: 8px 12px; /* Same padding as .btn for consistency */
    color: white;
    background-color: #218838; /* Same green color */
    border: none;
    border-radius: 5px; /* Rounded corners */
    cursor: pointer;
    font-size: 16px; /* Same font size as .btn */
    transition: opacity 0.3s ease; /* Smooth hover effect */
}

.back-btn:hover {
    opacity: 0.9; /* Same hover effect as .btn */
}

    </style>
</head>
<body>

    <div class="container">
        
        <h1>Student Center</h1>

         <h2>Contents</h2>
        
         <ul>
            <li><a href="addsbook.jsp" >Add Book</a></li>
            <li><a href="sbdata.jsp">Student Data</a></li>
	    <li><a href="FilterStats.jsp">Stats and Insights</a></li>
	    <li><a href="history.jsp">History</a></li>
        <li><a href="request.jsp">Book Requests</a></li>
        </ul>

    </div>

</body>
</html>
