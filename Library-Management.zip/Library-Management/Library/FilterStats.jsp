<%@ page session="true" %>
<%
    // Check if the user has a valid session and is an admin user (pvpsituser)
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("pvpsituser")) {
        // Redirect to login page if session is invalid or role is not "pvpsituser"
        response.sendRedirect("index.html");
        return; // Stop further processing of the page
    }
%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.format.TextStyle" %>
<%@ page import="java.util.Locale" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library and Attendance Statistics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        .chart-container {
            width: 45%;
            margin: 10px;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .charts-wrapper {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <h1>Library and Attendance Statistics</h1>
    <div class="charts-wrapper">
        <div class="chart-container">
            <h2>Books Borrowed - Last 7 Days</h2>
            <canvas id="chart7"></canvas>
        </div>
        <div class="chart-container">
            <h2>Books Borrowed - Last 30 Days</h2>
            <canvas id="chart30"></canvas>
        </div>
        <div class="chart-container">
            <h2>Attendance Count - Last 7 Days</h2>
            <canvas id="attendanceChart7"></canvas>
        </div>
        <div class="chart-container">
            <h2>Attendance Count - Last 30 Days</h2>
            <canvas id="attendanceChart30"></canvas>
        </div>
        <div class="chart-container">
            <h2>Books Borrowed - Last 12 Months</h2>
            <canvas id="chart12"></canvas>
        </div>
        <div class="chart-container">
            <h2>Attendance Count - Last 12 Months</h2>
            <canvas id="attendanceChart12"></canvas>
        </div>
        <div class="chart-container">
            <h2>Branch-wise Borrowing</h2>
            <canvas id="branchChart"></canvas>
        </div>
        <div class="chart-container">
            <h2>Branch-wise Attendance</h2>
            <canvas id="attendanceBranchChart"></canvas>
        </div>
    </div>

    <%
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String labels7 = "", data7 = "", labels30 = "", data30 = "", labels12 = "", data12 = "", 
               labelsAttendance7 = "", dataAttendance7 = "", labelsAttendance30 = "", dataAttendance30 = "",
               labelsAttendance12 = "", dataAttendance12 = "", branchLabels = "", branchData = "",
               attendanceBranchLabels = "", attendanceBranchData = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "sairam", "charan");

            // Query to fetch Books Borrowed - Last 7 Days
            String query7 = "SELECT DATE_FORMAT(transaction_date, '%a') AS label, COUNT(*) AS count " +
                            "FROM borrowing_history " +
                            "WHERE transaction_date >= CURDATE() - INTERVAL 7 DAY " +
                            "GROUP BY DATE_FORMAT(transaction_date, '%a')";
            pstmt = con.prepareStatement(query7);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labels7 += "'" + rs.getString("label") + "',";
                data7 += rs.getInt("count") + ","; 
            }

            // Query to fetch Books Borrowed - Last 30 Days
            String query30 = "SELECT DATE_FORMAT(transaction_date, '%d') AS label, COUNT(*) AS count " +
                             "FROM borrowing_history " +
                             "WHERE transaction_date >= CURDATE() - INTERVAL 30 DAY " +
                             "GROUP BY DATE_FORMAT(transaction_date, '%d')";
            pstmt = con.prepareStatement(query30);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labels30 += "'" + rs.getString("label") + "',";
                data30 += rs.getInt("count") + ",";
            }

            // Query to fetch Books Borrowed - Last 12 Months
            String query12 = "SELECT DATE_FORMAT(transaction_date, '%b-%y') AS label, COUNT(*) AS count " +
                             "FROM borrowing_history " +
                             "WHERE transaction_date >= CURDATE() - INTERVAL 12 MONTH " +
                             "GROUP BY DATE_FORMAT(transaction_date, '%b-%y')";
            pstmt = con.prepareStatement(query12);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labels12 += "'" + rs.getString("label") + "',";
                data12 += rs.getInt("count") + ",";
            }

            // Query to fetch Attendance Count - Last 7 Days
            String queryAttendance7 = "SELECT DATE_FORMAT(date_time, '%a') AS label, COUNT(*) AS count " +
                                      "FROM attendance " +
                                      "WHERE date_time >= CURDATE() - INTERVAL 7 DAY " +
                                      "GROUP BY DATE_FORMAT(date_time, '%a')";
            pstmt = con.prepareStatement(queryAttendance7);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labelsAttendance7 += "'" + rs.getString("label") + "',";
                dataAttendance7 += rs.getInt("count") + ",";
            }

            // Query to fetch Attendance Count - Last 30 Days
            String queryAttendance30 = "SELECT DATE_FORMAT(date_time, '%d') AS label, COUNT(*) AS count " +
                                        "FROM attendance " +
                                        "WHERE date_time >= CURDATE() - INTERVAL 30 DAY " +
                                        "GROUP BY DATE_FORMAT(date_time, '%d')";
            pstmt = con.prepareStatement(queryAttendance30);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labelsAttendance30 += "'" + rs.getString("label") + "',";
                dataAttendance30 += rs.getInt("count") + ",";
            }

            // Query to fetch Attendance Count - Last 12 Months
            String queryAttendance12 = "SELECT DATE_FORMAT(date_time, '%b-%y') AS label, COUNT(*) AS count " +
                                        "FROM attendance " +
                                        "WHERE date_time >= CURDATE() - INTERVAL 12 MONTH " +
                                        "GROUP BY DATE_FORMAT(date_time, '%b-%y')";
            pstmt = con.prepareStatement(queryAttendance12);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                labelsAttendance12 += "'" + rs.getString("label") + "',";
                dataAttendance12 += rs.getInt("count") + ",";
            }

            // Query for Branch-wise Borrowing
            String queryBranch = "SELECT branch, COUNT(*) AS count FROM students " +
                                 "INNER JOIN borrowing_history ON students.roll = borrowing_history.roll_no " +
                                 "GROUP BY branch";
            pstmt = con.prepareStatement(queryBranch);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                branchLabels += "'" + rs.getString("branch") + "',";
                branchData += rs.getInt("count") + ",";
            }

            // Query for Branch-wise Attendance
            String queryAttendanceBranch = "SELECT branch, COUNT(*) AS count FROM students " +
                                           "INNER JOIN attendance ON students.roll = attendance.roll " +
                                           "GROUP BY branch";
            pstmt = con.prepareStatement(queryAttendanceBranch);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                attendanceBranchLabels += "'" + rs.getString("branch") + "',";
                attendanceBranchData += rs.getInt("count") + ",";
            }

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    %>

    <script>
        var chart7 = new Chart(document.getElementById("chart7"), {
           type: 'line',
           data: {
               labels: [<%= labels7 %>],
               datasets: [{
                   label: 'Books Borrowed - Last 7 Days',
                   data: [<%= data7 %>],
                   borderColor: 'rgba(75, 192, 192, 1)',
                   fill: false
               }]
           }
       });

       var chart30 = new Chart(document.getElementById("chart30"), {
           type: 'line',
           data: {
               labels: [<%= labels30 %>],
               datasets: [{
                   label: 'Books Borrowed - Last 30 Days',
                   data: [<%= data30 %>],
                   borderColor: 'rgba(54, 162, 235, 1)',
                   fill: false
               }]
           }
       });

       var chart12 = new Chart(document.getElementById("chart12"), {
           type: 'line',
           data: {
               labels: [<%= labels12 %>],
               datasets: [{
                   label: 'Books Borrowed - Last 12 Months',
                   data: [<%= data12 %>],
                   borderColor: 'rgba(153, 102, 255, 1)',
                   fill: false
               }]
           }
       });

       var attendanceChart7 = new Chart(document.getElementById("attendanceChart7"), {
           type: 'line',
           data: {
               labels: [<%= labelsAttendance7 %>],
               datasets: [{
                   label: 'Attendance Count - Last 7 Days',
                   data: [<%= dataAttendance7 %>],
                   borderColor: 'rgba(255, 159, 64, 1)',
                   fill: false
               }]
           }
       });

       var attendanceChart30 = new Chart(document.getElementById("attendanceChart30"), {
           type: 'line',
           data: {
               labels: [<%= labelsAttendance30 %>],
               datasets: [{
                   label: 'Attendance Count - Last 30 Days',
                   data: [<%= dataAttendance30 %>],
                   borderColor: 'rgba(255, 99, 132, 1)',
                   fill: false
               }]
           }
       });

       var attendanceChart12 = new Chart(document.getElementById("attendanceChart12"), {
           type: 'line',
           data: {
               labels: [<%= labelsAttendance12 %>],
               datasets: [{
                   label: 'Attendance Count - Last 12 Months',
                   data: [<%= dataAttendance12 %>],
                   borderColor: 'rgba(75, 192, 192, 1)',
                   fill: false
               }]
           }
       });

       var branchChart = new Chart(document.getElementById("branchChart"), {
           type: 'pie',
           data: {
               labels: [<%= branchLabels %>],
               datasets: [{
                   data: [<%= branchData %>],
                   backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
               }]
           }
       });

       var attendanceBranchChart = new Chart(document.getElementById("attendanceBranchChart"), {
           type: 'pie',
           data: {
               labels: [<%= attendanceBranchLabels %>],
               datasets: [{
                   data: [<%= attendanceBranchData %>],
                   backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
               }]
           }
       });
   </script>
</body>
</html>


