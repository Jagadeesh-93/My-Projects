<%@ page import="java.sql.*, java.util.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance & Borrowing Trends</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <canvas id="last30DaysChart"></canvas>
    <canvas id="last12MonthsChart"></canvas>

    <%
        // Database Connection
        String url = "jdbc:mysql://localhost:3306/library";
        String user = "sairam";
        String pass = "charan";
        Connection conn = DriverManager.getConnection(url, user, pass);

        // Last 30 Days Data
        Map<String, Integer> attendanceMap = new LinkedHashMap<>();
        Map<String, Integer> borrowingMap = new LinkedHashMap<>();
        
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -30);

        for (int i = 0; i <= 30; i++) {
            String date = new java.text.SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
            attendanceMap.put(date, 0);
            borrowingMap.put(date, 0);
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }

        // Fetch Attendance Data
        String query = "SELECT DATE(date_time) as date, COUNT(*) as count FROM attendance WHERE date_time >= CURDATE() - INTERVAL 30 DAY GROUP BY date";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
            attendanceMap.put(rs.getString("date"), rs.getInt("count"));
        }

        // Fetch Borrowing Data
        query = "SELECT transaction_date as date, COUNT(*) as count FROM borrowing_history WHERE event_type='borrowing' AND transaction_date >= CURDATE() - INTERVAL 30 DAY GROUP BY transaction_date";
        rs = stmt.executeQuery(query);
        while (rs.next()) {
            borrowingMap.put(rs.getString("date"), rs.getInt("count"));
        }

        // Last 12 Months Data
        Map<String, Integer> monthlyAttendance = new LinkedHashMap<>();
        Map<String, Integer> monthlyBorrowing = new LinkedHashMap<>();

        for (int i = 11; i >= 0; i--) {
            String month = new java.text.SimpleDateFormat("yyyy-MM").format(new java.util.Date(new java.util.Date().getTime() - (i * 30L * 24 * 60 * 60 * 1000)));
            monthlyAttendance.put(month, 0);
            monthlyBorrowing.put(month, 0);
        }

        // Fetch Monthly Attendance
        query = "SELECT DATE_FORMAT(date_time, '%Y-%m') as month, COUNT(*) as count FROM attendance WHERE date_time >= CURDATE() - INTERVAL 12 MONTH GROUP BY month";
        rs = stmt.executeQuery(query);
        while (rs.next()) {
            monthlyAttendance.put(rs.getString("month"), rs.getInt("count"));
        }

        // Fetch Monthly Borrowing
        query = "SELECT DATE_FORMAT(transaction_date, '%Y-%m') as month, COUNT(*) as count FROM borrowing_history WHERE event_type='borrowing' AND transaction_date >= CURDATE() - INTERVAL 12 MONTH GROUP BY month";
        rs = stmt.executeQuery(query);
        while (rs.next()) {
            monthlyBorrowing.put(rs.getString("month"), rs.getInt("count"));
        }

        conn.close();

        // Convert Data to JSON-like Format
        String labels30 = new ArrayList<>(attendanceMap.keySet()).toString();
        String attendanceData = new ArrayList<>(attendanceMap.values()).toString();
        String borrowingData = new ArrayList<>(borrowingMap.values()).toString();

        String labels12 = new ArrayList<>(monthlyAttendance.keySet()).toString();
        String monthlyAttendanceData = new ArrayList<>(monthlyAttendance.values()).toString();
        String monthlyBorrowingData = new ArrayList<>(monthlyBorrowing.values()).toString();
    %>

    <script>
        let labels30 = <%= labels30 %>;
        let attendanceData = <%= attendanceData %>;
        let borrowingData = <%= borrowingData %>;

        let labels12 = <%= labels12 %>;
        let monthlyAttendanceData = <%= monthlyAttendanceData %>;
        let monthlyBorrowingData = <%= monthlyBorrowingData %>;

        new Chart(document.getElementById("last30DaysChart"), {
            type: 'line',
            data: {
                labels: labels30,
                datasets: [
                    { label: 'Attendance', data: attendanceData, borderColor: 'blue', fill: false },
                    { label: 'Book Borrowing', data: borrowingData, borderColor: 'green', fill: false }
                ]
            },
            options: { responsive: true }
        });

        new Chart(document.getElementById("last12MonthsChart"), {
            type: 'bar',
            data: {
                labels: labels12,
                datasets: [
                    { label: 'Attendance', data: monthlyAttendanceData, backgroundColor: 'blue' },
                    { label: 'Book Borrowing', data: monthlyBorrowingData, backgroundColor: 'green' }
                ]
            },
            options: { responsive: true }
        });
    </script>

</body>
</html>
