
<%@ page import="java.sql.*" %>
<%@ include file="header.jsp" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        /* Container for the login form */
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 35px;
            background-color: white;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }

        .container:hover {
            transform: translateY(-5px);
        }

        h1 {
            font-size: 30px;
            margin-bottom: 30px;
            color:#155d4d;
            font-weight: bold;
        }

        label {
            font-size: 14px;
            color: #333;
            text-align: left;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"], input[type="password"] {
            width: 90%;
            padding: 12px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fafafa;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #1e73be;
            outline: none;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .submit-btn {
            width: 60%;
            padding: 12px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            color: white;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #218838;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 15px;
        }

        a {
            display: block;
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #1e73be;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #155d4d;
        }

        /* Responsive design for smaller screens */
        @media (max-width: 480px) {
            .container {
                margin: 50px 20px;
                padding: 25px;
            }

            h1 {
                font-size: 26px;
            }

            .submit-btn {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Login</h1>
        
        <form method="post" action="">
            <div class="form-group">
                <label for="username"><b>Student Roll No:</b></label>
                <input type="text" id="username" name="roll_no" required>
            </div>

            <div class="form-group">
                <label for="password"><b>Password:</b></label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="submit-btn">Login</button>
            <a href='change-password.jsp'>Change Password</a>
        </form>

        <div class="error">
            <%
                String errorMessage = (String) request.getAttribute("errorMessage");
                if (errorMessage != null) {
                    out.println(errorMessage);
                }
            %>
        </div>
    </div>

<%
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/library"; // Change to your database name
    String user = "sairam"; // Change to your database username
    String password = "charan"; // Change to your database password

    if (request.getMethod().equalsIgnoreCase("POST")) {
        // Get form data
        String rollNo = request.getParameter("roll_no");
        String enteredPassword = request.getParameter("password");

        // SQL query to check if the roll number exists and match password
        String sql = "SELECT * FROM students WHERE roll = ? AND password = ?";

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            Connection conn = DriverManager.getConnection(url, user, password);

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, rollNo);
            pstmt.setString(2, enteredPassword);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Check if the logged-in user is 'pvpsituser'
                String username = rs.getString("roll");
                if (username.equals("pvpsituser")) {
                    // Set session attribute for admin
                    session.setAttribute("role", "pvpsituser");
                    // Redirect to index2.jsp for pvpsituser
                    response.sendRedirect("simple.jsp");
                } else {
                    // For other users, redirect to student dashboard
                    session.setAttribute("rollNo", rollNo);
                    response.sendRedirect("student-dashboard.jsp");
                }
            } else {
                // Incorrect credentials
                request.setAttribute("errorMessage", "Invalid credentials. Please try again.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

            // Close resources
            rs.close();
            pstmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }
%>

</body>
</html>
